﻿namespace $safeprojectname$;

public interface I$ext_entityName$Client : IRestClient<$ext_entityName$Dto>
{
}
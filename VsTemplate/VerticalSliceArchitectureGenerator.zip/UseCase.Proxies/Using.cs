﻿global using Core.Proxying;

global using $ext_safeprojectname$.Dtos;
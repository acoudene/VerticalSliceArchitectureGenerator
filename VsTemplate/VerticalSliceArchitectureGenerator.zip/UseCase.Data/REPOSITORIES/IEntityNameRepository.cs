﻿using $safeprojectname$.Entities;

namespace $safeprojectname$.Repositories;

public interface I$ext_entityName$Repository : IRepository<$ext_entityName$>
{
}

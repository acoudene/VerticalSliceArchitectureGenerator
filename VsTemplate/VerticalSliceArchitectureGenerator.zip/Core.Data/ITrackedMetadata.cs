﻿namespace $safeprojectname$;

public interface ITrackedMetadata
{
  DateTimeOffset LoggedAt { get; }
}

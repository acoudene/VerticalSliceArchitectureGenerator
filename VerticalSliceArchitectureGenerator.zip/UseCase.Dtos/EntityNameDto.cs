﻿namespace $safeprojectname$;

public class $ext_entityName$Dto : IIdentifierDto
{
  public Guid Id { get; set; }
}
﻿namespace $safeprojectname$.Entities;

public record $ext_entityName$ : IIdentifierEntity
{
    public Guid Id { get; set; }
}
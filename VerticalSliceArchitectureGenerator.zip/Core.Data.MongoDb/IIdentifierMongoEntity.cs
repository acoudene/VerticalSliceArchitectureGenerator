﻿namespace $safeprojectname$;

public interface IIdentifierMongoEntity : IIdentifierEntity, IMongoEntity
{
}

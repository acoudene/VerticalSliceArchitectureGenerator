﻿global using Core.Api;
global using Microsoft.AspNetCore.Mvc;

global using $ext_safeprojectname$.Dtos;
global using $ext_safeprojectname$.Data.Entities;
global using $ext_safeprojectname$.Data.Repositories;
﻿global using Core.Data;
global using Core.Data.MongoDb;
global using MongoDB.Bson;
global using MongoDB.Bson.Serialization.Attributes;

global using $safeprojectname$.Entities;
global using $ext_safeprojectname$.Data.Entities;
global using $ext_safeprojectname$.Data.Repositories;
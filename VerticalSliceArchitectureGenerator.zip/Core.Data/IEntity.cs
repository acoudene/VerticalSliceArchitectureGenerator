﻿namespace $safeprojectname$;

public interface IEntity
{
}

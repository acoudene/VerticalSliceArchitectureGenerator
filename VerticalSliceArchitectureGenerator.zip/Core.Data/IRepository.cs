﻿namespace $safeprojectname$;

public interface IRepository
{
}
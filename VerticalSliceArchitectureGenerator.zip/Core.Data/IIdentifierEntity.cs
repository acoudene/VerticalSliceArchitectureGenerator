﻿namespace $safeprojectname$;

public interface IIdentifierEntity : IEntity
{
    Guid Id { get; set; }
}

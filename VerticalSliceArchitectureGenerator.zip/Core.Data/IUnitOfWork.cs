﻿namespace $safeprojectname$;

public interface IUnitOfWork
{

}
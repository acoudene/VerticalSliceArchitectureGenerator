﻿namespace $safeprojectname$;

public interface IIdentifierDto : IDto
{
    Guid Id { get; set; }
}

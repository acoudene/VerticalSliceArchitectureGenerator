﻿namespace $safeprojectname$;

public interface IDto
{
}

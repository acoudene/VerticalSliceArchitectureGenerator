﻿namespace $safeprojectname$.Swaggers;

[AttributeUsage(AttributeTargets.Class)]
public class SwaggerExcludeAttribute : Attribute
{
}

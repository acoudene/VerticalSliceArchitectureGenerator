global using Core.Host.Testing.Api.MongoDb;
global using Microsoft.AspNetCore.Mvc.Testing;
global using Xunit;
global using Xunit.Abstractions;

global using $ext_safeprojectname$.Dtos;
global using $ext_safeprojectname$.Proxies;
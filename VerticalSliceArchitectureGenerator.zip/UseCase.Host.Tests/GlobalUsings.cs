global using Core.Host.Testing.Api.MongoDb;
global using $ext_safeprojectname$.Dtos;
global using $ext_safeprojectname$.Proxies;
global using Microsoft.AspNetCore.Mvc.Testing;
global using Xunit;
global using Xunit.Abstractions;